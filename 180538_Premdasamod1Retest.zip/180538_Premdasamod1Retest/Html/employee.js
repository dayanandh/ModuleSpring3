function emp()
{
	alert("All data for entered successfully);

	
}