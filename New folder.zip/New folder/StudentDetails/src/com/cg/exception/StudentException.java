package com.cg.exception;

public class StudentException extends Exception{

	public StudentException()
	{
		
	}
	public StudentException(String msg)
	{
		super(msg);
	}

}
