package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Student;

@Repository
public class StudentRepositoryImpl implements StudentRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Student save(Student student) {

		entityManager.persist(student);
		entityManager.flush();
		return student;
	}

	@Override
	public List<Student> showAllStudents() {
		String qry = "SELECT std FROM Student std";
		TypedQuery<Student> query = entityManager.createQuery(
				qry, Student.class);
		return query.getResultList();

	}

	@Override
	public Student findById(int id) {
		return entityManager.find(Student.class,id);
	}

	@Override
	public Student delete(int id) {
		Student student = entityManager.find(Student.class,id);
		if (student != null)
		{
			entityManager.remove(student);
		}
		return student;
	}

	@Override
	public boolean isValidStudentId(int studentId) {
		boolean status=false;
		System.out.println("studentId="+studentId);
    	String sql="SELECT 1 FROM student WHERE studentId=?";
		Object[] params=new Object[]{studentId};
		int iStatus= entityManager.merge(studentId);
		if(iStatus>0)
		{
			status=true;
		}
		
		return status;
		
	}
	@Override
	public Student getStudentDetails(int studentId) {		
		return entityManager.find(Student.class, studentId);
	}

}
